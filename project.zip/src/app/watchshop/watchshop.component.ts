import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-watchshop',
  templateUrl: './watchshop.component.html',
  styleUrls: ['./watchshop.component.css']
})
export class WatchshopComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
